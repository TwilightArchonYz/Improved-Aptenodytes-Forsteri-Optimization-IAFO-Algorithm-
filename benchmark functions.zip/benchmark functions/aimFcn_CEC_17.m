function fit=aimFcn_CEC_17(x,option,data)
    x=checkX(x,option);
    fit=cec17_func(x',option.pro);
end