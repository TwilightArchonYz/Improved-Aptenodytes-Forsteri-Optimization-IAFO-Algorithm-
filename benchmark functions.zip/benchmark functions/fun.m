function y=fun(x)
    y=sum(x.^2);
end