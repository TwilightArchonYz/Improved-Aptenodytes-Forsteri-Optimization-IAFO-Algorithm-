%% 群智能算法对比试验
clc;
clear;
close all
rng('default')
warning off
%% 选择测试函数
% addpath(genpath('CEC2017'))
% addpath('code');
addpath('input_data');
fobj=@aimFcn_CEC_17;
dim=30;
lb=-ones(1,dim)*100;
ub=ones(1,dim)*100;
option.lb=lb;
option.ub=ub;
option.dim=dim;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end
option.fobj=fobj;

option.showIter=0;
option.v_lb=-(option.ub-option.lb)/20;
option.v_ub=(option.ub-option.lb)/20;
%% 算法参数设置
% 基本参数
option.numAgent=150;        %种群个体数
option.maxIteration=dim*10000/option.numAgent;    %最大迭代次数
option.maxEfs=dim*10000;
% 遗传算法
option.p1_GA=0.9;
option.p2_GA=0.1;
% 粒子群群算法
option.c1_pso=1.2;
option.c2_pso=1.2;
option.w_pso=0.8;
%% DE
option.F=0.5;
option.CR=0.5;
%% AFO
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=1/3; %weight of Moving strategy III
option.w4=1/3;%weight of Moving strategy III
option.w5=1/3;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
%% Imroved AFO
option.P_stratage=[0.2,0.4,0.4];
option.p=0.1;
option.gama=1;
option.alpha=10;
option.repeatNum=8; %重复试验100次
data=[];
%parpool(8)
%%
str_legend=[{'IAFO'},{'AFO2'},{'AFO3'}];
selectedAlgorithm=[{@IAFO_Final1},{@AFO2},{@AFO3}];
noPro=[1:30];
noPro(2)=[];
bestValue=noPro*100;
for j=1:length(noPro)
    option.pro=noPro(j);
    disp(option.pro)
    for ii=1:option.repeatNum
        %% 初始化种群个体
        rng(ii)
        x=ones(option.numAgent,option.dim);
        y=ones(option.numAgent,1);
        for i=1:option.numAgent
            x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
            y(i)=option.fobj(x(i,:),option);
        end
        %% 使用算法求解
        for i=1:length(selectedAlgorithm)
            rng(ii)
            tic
            [bestY{ii}(i,j),~,recording{ii}(i,j)]=selectedAlgorithm{i}(x,y,option,data);
            recordingT{ii}(i,j)=toc;
        end
    end
end
%% 整理数据
maxEFs=(option.maxIteration)*option.numAgent;
for j=1:length(noPro)
    for i=1:length(selectedAlgorithm)
        for ii=1:option.repeatNum
            recordingY{j}(i,ii)=bestY{ii}(i,j);
        end
        recordingY0(j,i)=mean(recordingY{j}(i,:));
    end
end
%%
% for j=1:length(noPro)
%     figure
%     hold on
%     for i=1:length(selectedAlgorithm)
%         if i<=7
%             plot(log(mean(recordingCruve_EFs{i,j})),'-','LineWidth',2)
%         else
%             plot(log(mean(recordingCruve_EFs{i,j})),'--','LineWidth',2)
%         end
%     end
%     legend(str_legend)
%     xlabel('EFs')
% end
%%
for i=1:length(selectedAlgorithm)
    result.recordingCruve_EFs=[];
    for j=1:length(noPro)
        result.recordingY{j}=recordingY{j}(i,:);
    end
    result.recordingY0=recordingY0(:,i);
    save(['result-',str_legend{i},'-',date],"result")
end