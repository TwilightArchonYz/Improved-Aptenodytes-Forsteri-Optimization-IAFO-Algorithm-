function [bestY,bestX,recording]=IAFO(x,y,option,data)
%% 改进AFO算法
%  策略1-概率固定
%  策略2 3-自适应控制
%% Authority
% Author: Zhe Yang
% E-mail: 454170989@qq.com
% School: University of Manchester
%% Input
% x----positions of initialized populaiton
% y----fitnesses of initialized populaiton
% option-----parameters set of the algorithm
% data------Pre-defined parameters
% This parameter is used for solving complex problems is passing case data
%% outPut
% bestY ----fitness of best individual
% bestX ----position of best individual
% recording ---- somme data was recorded in this variable
%% initialization
numAgent=option.numAgent;
dim=option.dim;
maxIteration=option.maxIteration;
w2=option.w2; %weight of Moving strategy III
w4=option.w4;%weight of Moving strategy III
w5=option.w5;%weight of Moving strategy III
ub=option.ub;
lb=option.lb;
v_lb=option.v_lb;
v_ub=option.v_ub;
fobj=option.fobj;
%% 中间变量
x_m1=zeros(numAgent,dim);
x_2=zeros(numAgent,dim);
AI=zeros(numAgent,dim);
At=randn(numAgent,dim);
%% 记录数据
recording.bestFit=zeros(maxIteration+1,1);
recording.meanFit=zeros(maxIteration+1,1);
recording.bestFit_EFs=zeros((option.maxIteration+1)*option.numAgent,1);
recording.meanFit_EFs=recording.bestFit_EFs;
%% center of population
[y_c,position]=min(y);
x_c=x(position(1),:);
At_c=At(position(1),:);
%% memory of population
y_m=y;
x_m=x;
%%
P_stratage=option.P_stratage; %三种更新方式的
for i=1:3
    P_stratage0(i)=sum(P_stratage(1:i));
end
%% update recording

iter=1;
EFs0=1;
EFs=numAgent;
recording.bestFit(1)=y_c;
recording.meanFit(1)=mean(y_m);
recording.bestFit_EFs(EFs0:EFs)=y_c;
recording.meanFit_EFs(EFs0:EFs)=mean(y_m);
x1=x;
P_stratageR=[];
while EFs<=(maxIteration+1)*numAgent
    EFs0=EFs+1;
    y0=y;
    x0=x;
    %% 以概率生成每个个体采取的策略
    RS=rand(numAgent,1);
    indexS=zeros(numAgent,1);
    p1=find(RS<P_stratage0(1));
    p2=find(RS<P_stratage0(2) & RS>=P_stratage0(1));
    p3=find(RS<=P_stratage0(3) & RS>=P_stratage0(2));
    indexS(p1)=1;
    indexS(p2)=2;
    indexS(p3)=3;
    for i=1:3
        position=find(indexS==i);
        if isempty(position)
            indexS(randi(numAgent))=i;
        end
    end
    %% 初始化随机变量（便于矩阵操作）
    R1=rand(numAgent,dim);
    R2=rand(numAgent,dim);
    R3=rand(numAgent,dim);
    Rn=rand(numAgent,dim);
    indexR1=randi(numAgent,numAgent,dim);
    indexR2=randi(numAgent,numAgent,dim);
%     indexR3=randi(numAgent,numAgent,dim);
%     indexR4=randi(numAgent,numAgent,dim);
    %% 成功更新的标记
    flag=zeros(numAgent,1);
    gama=option.gama;
    for j=1:dim
        x_m1(:,j)=x_m(indexR1(:,j),j);
        x_2(:,j)=x(indexR2(:,j),j);
        AI(:,j)=gama*R1(:,j).*(x_m1(:,j)-x_2(:,j));
    end
    numEfs_S1=0;
    for i=1:numAgent
        if indexS(i)==1
            while 1
                flag0=0;
                output.iterations=min(10,ceil(rand*option.dim));
                for ii=1:output.iterations
                    index=randperm(dim,2);
                    newX=x(i,:);
                    newX(index)=newX(index(end:-1:1));
                    newY=fobj(newX,option,data);
                    if newY<y(i)
                        y(i)=newY;
                        x(i,:)=newX;
                        flag0=1;
                        flag(i)=flag(i)+1;
                    end
                end
                if flag0==0
                    break;
                end
                EFs=EFs+output.iterations;
                numEfs_S1=numEfs_S1+output.iterations;
            end
        elseif indexS(i)==2
            % EQ 2-28
            At(i,:)=w2*At(i,:)+w4*R2(i,:).*(x_c-x(i,:))+w5*R3(i,:).*(x_m(i,:)-x(i,:));
            x(i,:)=x(i,:)+At(i,:); %EQ 2-29
            x(i,x(i,:)<lb)=lb(x(i,:)<lb);
            x(i,x(i,:)>ub)=ub(x(i,:)>ub);
            y(i)=fobj(x(i,:),option,data);
            EFs=EFs+1;
        else
            x(i,:)=x_c+AI(i,:);
            x(i,Rn(i,:)>0.5)=x_c(Rn(i,:)>0.5);
            At(i,:)=AI(i,:);
            x(i,x(i,:)<lb)=lb(x(i,:)<lb);
            x(i,x(i,:)>ub)=ub(x(i,:)>ub);
            y(i)=fobj(x(i,:),option,data);
            EFs=EFs+1;
        end
        if y(i)<y0(i)
            flag(i)=flag(i)+1;
        end
        if y(i)<y_m(i)
            y_m(i)=y(i);
            x_m(i,:)=x(i,:);
            if y_m(i)<y_c
                y_c=y_m(i);
                x_c=x_m(i,:);
            end
        end
    end
    %% 更新三种策略的比例
    P_stratage1=[0,0,0];
    for i=1:3
        position=find(flag>=1 & indexS==i);
        position1=find(indexS==i);
        if i==1
            P_stratage1(i)=sum(flag(position))/(numEfs_S1+eps);
        else
            P_stratage1(i)=sum(flag(position))/(length(position1)+eps);
        end    
    end
    P_stratageR=[P_stratageR;P_stratage1];
    if iter>1
        c=0.1;
        P_stratage1=c*P_stratage1+(1-c)*P_stratageR(end,:);
    end
    if sum(P_stratage1)==0
        P_stratage1=option.P_stratage; %三种更新方式的
    else
        P_stratage1=P_stratage1/sum(P_stratage1);
    end
    for i=1:3
        P_stratage0(i)=sum(P_stratage(1:i));
    end
    iter=iter+1;
%     % 延缓收敛速度
%     std0=exp(-option.alpha*EFs/option.maxEfs)*(ub-lb)/10;
%     std1=std(x_m);
%     x1=[x1;x(flag==0,:)];
%     numX0=length(x1(:,1));
%     if numX0==0
%         x1=x;
%         numX0=length(x1(:,1));
%     end
%     for j=1:dim
%         if std1(j)<std0(j)
%             if std(x1(:,j))>std0(j)
%                 for i=1:option.p*numAgent
%                     x_m(indexR2(i),j)=x1(randi(numX0),j);
%                     y_m(indexR2(i))=inf;
%                 end
%             else
%                 for i=1:option.p*numAgent
%                     x_m(indexR2(i),j)=x1(randi(numX0),j)+randn*std0(j);
%                     y_m(indexR2(i))=inf;
%                 end
%             end
%         end
%     end
%     x1=[x(flag==0,:)];
    %% 记录数据
    recording.bestFit_EFs(EFs0:EFs)=y_c;
    recording.meanFit_EFs(EFs0:EFs)=mean(y_m);
    recording.bestFit(iter)=y_c;
    recording.meanFit(iter)=mean(y_m);
    %% 算法结束
    if EFs>option.maxEfs
        break
    end
end
bestY=y_c;
bestX=x_c;
end
%%
