function y=aimFcn_Engineering(x,option,data)
x(x<=0)=0+eps;
x(x>1)=1;
if option.no==1

    %% Three bar truss design
    x_lb=0;
    x_ub=1;
    l=100;
    P=2;
    sigma=2;
    %
    x=(x_ub-x_lb).*x+x_lb;
    %
    g(1)=(sqrt(2)*x(1)+x(2))/(sqrt(2)*x(1)^2+2*x(1)*x(2))*P-sigma;
    g(2)=(x(2))/(sqrt(2)*x(1)^2+2*x(1)*x(2))*P-sigma;
    g(3)=(1/(sqrt(2)*x(2)+x(1)))*P-sigma;
    %
    punishiment=0;
    punishiment=punishiment+sum(g(g>0));
    y=(2*sqrt(2)*x(1)+x(2))*l+punishiment;
elseif option.no==2
    %% Welded beam structure problem
    x_lb=[0.1,0.1,0.1,0.1];
    x_ub=[2,10,10,2];
    tau_max=13600;
    sigma_max=30000;
    G=12e6;
    E=30e6;
    delta_max=0.25;
    L=14;
    P=6000;
    %
    x=(x_ub-x_lb).*x+x_lb;
    %
    Pc=4.013*E*sqrt(x(3)^2*x(4)^6/36)/L^2*(1-x(3)/2/L*sqrt(E/4/G));
    delta=4*P*L^3/E/x(3)^3/x(4);
    sigma=6*P*L/x(3)^2/x(4);
    J=2*(sqrt(2)*x(1)*x(2)*(x(2)^2/12+((x(1)+x(3))/2^2)));
    R=sqrt(x(2)^2/4+((x(1)+x(3))/2)^2);
    M=P*(L+x(2)/2);
    tau2=M*R/J;
    tau1=P/(sqrt(2)*x(1)*x(2));
    tau=sqrt(tau1^2+2*tau1*tau2*x(2)/2/R+tau2^2);
    %
    g(1)=tau-tau_max;
    g(2)=sigma-sigma_max;
    g(3)=delta-delta_max;
    g(4)=x(1)-x(4);
    g(5)=P-Pc;
    g(6)=0.125-x(1);
    g(7)=1.10471*x(1)*2+0.04811*x(4)*x(3)*(14+5);
    %
    punishiment=0;
    punishiment=punishiment+sum(g(g>0));
    %
    y=1.10471*x(1)*2+0.04811*x(4)*x(3)*(14+x(2))+punishiment;
elseif option.no==3
    %% tension/Compression spring design problem
    x_lb=0.01;
    x_ub=100;
    %
    g(1)=1-x(2)^3*x(3)/71785/x(1)^4;
    g(2)=(4*x(2)^2-x(1)*x(2))/12566*(x(2)*x(1)^3-x(1)^4)+1/5108/x(1)^2-1;
    g(3)=1-140.45*x(1)/x(2)^2/x(3);
    g(4)=(x(1)+x(2))/1.5-1;
    %
    punishiment=0;
    punishiment=punishiment+sum(g(g>0));
    %
    y=(x(3)+2)*x(2)*x(1)+punishiment;
elseif option.no==4
    %%
    g(1)=61/x(1)^3+61/x(1)^3+61/x(1)^3+61/x(1)^3+61/x(1)^3-1;
    %
    punishiment=0;
    punishiment=punishiment+sum(g(g>0));
    y=0.6224*sum(x)+punishiment;

end
end