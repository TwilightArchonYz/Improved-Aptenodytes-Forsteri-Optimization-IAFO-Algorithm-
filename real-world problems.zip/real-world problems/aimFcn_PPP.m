function [fit,result]=aimFcn_1(x,option,data)
    flag=zeros(length(data.net(:,1)),1);
    S=data.noS;
    E=data.noE;
    path=[S];
    D=0;
    while S~=E
        position=find(data.net(:,1)==S & flag==0);
        if isempty(position)
            S=path(end-1);
            path(end)=[];
            continue;
        end
        nextNode=data.net(position,2);
        D2=data.D1(nextNode);
        D1=data.net(position,3);
        pri=x(position)';
        temp=(D1+D2).*pri.^0.1;
        [~,no]=min(temp);
        S=data.net(position(no),2);
        D=D+data.net(position(no),3);
        flag(position(no))=1;
        path=[path;S];
    end
    fit=D;
    if nargout>1
        result.fit=fit;
        result.path=path;
    end
end