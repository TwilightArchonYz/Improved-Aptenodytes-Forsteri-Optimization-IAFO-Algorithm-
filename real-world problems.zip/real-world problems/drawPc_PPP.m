function drawPC(result,option,data,str)
    figure
    hold on
    [p1,p2]=find(data.map==1);
    for i=1:length(p1)
        rectangle('Position',[p1(i)-0.5,p2(i)-0.5,1,1],'FaceColor','k');
    end
    [p1,p2]=find(data.map==0);
    for i=1:length(p1)
        rectangle('Position',[p1(i)-0.5,p2(i)-0.5,1,1],'FaceColor','w');
    end
    plot(data.node(result.path,1),data.node(result.path,2),'LineWidth',2)
    title([str,',fit��',num2str(result.fit)]);
    axis([0.5,0.5+data.sizeMap0,0.5,0.5+data.sizeMap0])
    set(gca,'LooseInset',get(gca,'TightInset'))
end