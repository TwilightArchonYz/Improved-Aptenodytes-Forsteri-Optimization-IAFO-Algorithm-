clc;
clear;
close all
rng('default')
warning off
%% ѡ����Ժ���
fobj=@aimFcn_Engineering;
option.fobj0=@aimFcn_Engineering;
option.fobj=@aimFcn_Engineering;
dim=30;
lb=-ones(1,dim)*0;
ub=ones(1,dim)*1;
option.lb=lb;
option.ub=ub;
option.dim=dim;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end
option.fobj=fobj;

option.showIter=0;
option.v_lb=-(option.ub-option.lb)/20;
option.v_ub=(option.ub-option.lb)/20;
%% �㷨��������
% ��������
option.numAgent=100;        %��Ⱥ������
option.maxIteration=dim*1000/option.numAgent;    %����������
option.maxEfs=dim*1000;
% �Ŵ��㷨
option.p1_GA=0.9;
option.p2_GA=0.1;
% ����ȺȺ�㷨
option.c1_pso=1.2;
option.c2_pso=1.2;
option.w_pso=0.8;
%% DE
option.F=0.5;
option.CR=0.5;
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=1/3; %weight of Moving strategy III
option.w4=1/3;%weight of Moving strategy III
option.w5=1/3;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
%% Imroved AFO
option.P_stratage=[0.2,0.1,0.7];
option.p=0.1;
option.alpha=10;
option.gama=1;
%%
%parpool(8)
option.repeatNum=8; %�ظ�����100��
data=[];
%%
str_legend=[{'IAFO-E1'}];
selectedAlgorithm=[{@IAFO_Final0}];
noPro=[1:4];
D=[2,4,4,5];
for j=1:length(noPro)
    option.pro=noPro(j);
    option.no=noPro(j);
    dim=D(j);
    option.dim=dim;
    lb=-ones(1,dim)*0;
    ub=ones(1,dim)*1;
    option.lb=lb;
    option.ub=ub;
    disp(option.pro)
    %%
    parfor ii=1:option.repeatNum
        %% ��ʼ����Ⱥ����
        rng(ii)
        x=ones(option.numAgent,option.dim);
        y=ones(option.numAgent,1);
        for i=1:option.numAgent
            x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
            y(i)=option.fobj(x(i,:),option);
        end
        %% ʹ���㷨���
        for i=1:length(selectedAlgorithm)
            rng(ii)
            tic
            [bestY{ii}(i,j),~,~]=selectedAlgorithm{i}(x,y,option,data);
            recordingT{ii}(i,j)=toc;
        end
    end
end
%% ��������
maxEFs=(option.maxIteration)*option.numAgent;
for j=1:length(noPro)
    for i=1:length(selectedAlgorithm)
        for ii=1:option.repeatNum
            recordingY{j}(i,ii)=bestY{ii}(i,j);
        end
        recordingY0(j,i)=mean(recordingY{j}(i,:));
    end
end
%%
for i=1:length(selectedAlgorithm)
    result.recordingCruve_EFs=[];
    for j=1:length(noPro)
        result.recordingY{j}=recordingY{j}(i,:);
    end
    result.recordingY0=recordingY0(:,i);
    save(['result-',str_legend{i},'-',date],"result")
end