%% 2021.9.2 ������㷨��TSP����
% 2021.9.2 AFO TSP problems
%% �����̶�
% TSP issues with different starting points and a fixed number of travellers
%% ����ʹ��ԭʼ�㷨��ֱ�������������ר���ڱ�����ĸ��·�ʽ���Խ�һ����߾���
% This is the direct result of using the original algorithm,
% adding some specific update methods to this problem can further improve the accuracy
clc;
clear;
close all;
warning off

%% �̶����������
noRNG=1;
rng('default')
rng(noRNG)

%% ��������
data.numPJM=[3,5,7,9,11;
    5,10,20,70,90;
    3,5,7,15,19];
data.boundT=[5,10];
noPro=[1:length(data.numPJM(1,:))];
%parpool(8)
option.repeatNum=24;
%%
j=1;
%% �����������
data.Process=[];
data.numJ=data.numPJM(2,j);
data.numM=data.numPJM(1,j);
data.numP0=data.numPJM(3,j);
for noJ=1:data.numJ
    for noP=1:data.numP0
        data.Process=[data.Process;noJ,noP,rand(1,data.numM)*(data.boundT(2)-data.boundT(1))+data.boundT(1)];
    end
end
%%
data.numP=length(data.Process(:,1));
dim=data.numP*data.numM;
%%
option.dim=dim;
lb=0;
ub=1;
option.lb=lb;
option.ub=ub;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end

%option.fobj0=option.fobj;
option.showIter=0;
%% �㷨�������� Parameters
% ��������
option.numAgent=100;        %��Ⱥ������

% ������㷨
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=0.5; %weight of Moving strategy III
option.w4=1;%weight of Moving strategy III
option.w5=1;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence

option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
%%
option.p1_GA=0.9;
option.p2_GA=0.1;
%% DE
option.F=0.5;
option.CR=0.5;
%% Imroved AFO
option.P_stratage=[0.05,0.2,0.7];
option.p=0.1;
option.alpha=10;
option.gama=1;
str_legend=[{'IAFO'}];
selectedAlgorithm=[{@IAFO_Final1}];
option.maxIteration=data.numJ*1000/option.numAgent;    %����������
option.maxEfs=data.numJ*1000;
option.dim=dim;
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
lb=-ones(1,dim)*0;
ub=ones(1,dim)*1;
option.lb=lb;
option.ub=ub;
%%
%% ��ʼ����Ⱥ����
%% ʹ���㷨���
for ii=1:length(selectedAlgorithm)
    option.fobj=@aimFcn_FJSP;
    x=ones(option.numAgent,option.dim);
    y=ones(option.numAgent,1);
    for i=1:option.numAgent
        x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
        y(i)=option.fobj(x(i,:),option,data);
    end
    rng(noRNG)
    tic
    [bestY(ii,:),bestX(ii,:),recording{ii}]=selectedAlgorithm{ii}(x,y,option,data);
    recordingT(ii,j)=toc;
end
%%
figure
hold on
plot(recording{1}.bestFit_EFs(1:option.maxEfs),'LineWidth',2)
legend(str_legend)
set(gca,'LooseInset',get(gca,'TightInset'))
%%
rng(1)
option.color=rand(50,3)*0.5+0.5;
for ii=1:length(selectedAlgorithm)
    option.fobj=@aimFcn_FJSP;
    str=str_legend{ii};
    [fit(ii),result(ii)]=option.fobj(bestX(ii,:),option,data);
    drawPc_FJSP(result(ii),option,data,str)
end