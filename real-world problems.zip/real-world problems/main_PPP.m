%% 2022.3.25 改进帝企鹅算法：path planning problem问题
% 2022.3.25 IAFO path planning problem problems
%% 这是使用原始算法的直接求解结果，添加专用于本问题的更新方式可以进一步提高精度
% This is the direct result of using the original algorithm,
% adding some specific update methods to this problem can further improve the accuracy
clc;
clear;
close all;
warning off

%% 固定随机数种子
noRNG=1;
rng('default')
rng(noRNG)

%% 载入数据
data.numPJM=[3,5,7,9,11;
    5,10,20,70,90;
    3,5,7,15,19];
data.boundT=[5,10];
noPro=[1:length(data.numPJM(1,:))];
%parpool(8)
option.repeatNum=24;
%%
j=1;
%% 随机生成数据
data.sizeMap=20:20:100;
mapSize=data.sizeMap(j);
%%
data.map=rand(mapSize)<0.2;
data.S=[1,1];
data.E=[mapSize,mapSize];
data.map(data.S(1),data.S(2))=0;
data.map(data.E(1),data.E(2))=0;
[p1,p2]=find(data.map==0);
data.node=[p1,p2];
data.noS=find(p1==data.S(1) & p2==data.S(2));
data.noE=find(p1==data.E(1) & p2==data.E(2));
data.D=pdist2(data.node,data.node);
data.D1=pdist2(data.node,data.E);
[p1,p2]=find(data.D<=sqrt(2));
index=sub2ind([length(data.node(:,1)),length(data.node(:,1))],p1,p2);
data.net=[p1,p2,data.D(index)];
dim=length(index);
option.maxEfs=mapSize*1000;
%%
option.dim=dim;
lb=0;
ub=1;
option.lb=lb;
option.ub=ub;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end

%option.fobj0=option.fobj;
option.showIter=0;
%% 算法参数设置 Parameters
% 基本参数
option.numAgent=100;        %种群个体数

% 帝企鹅算法
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=0.5; %weight of Moving strategy III
option.w4=1;%weight of Moving strategy III
option.w5=1;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence

option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
%%
option.p1_GA=0.9;
option.p2_GA=0.1;
%% DE
option.F=0.5;
option.CR=0.5;
%% Imroved AFO
option.P_stratage=[0.05,0.2,0.7];
option.p=0.1;
option.alpha=10;
option.gama=1;
str_legend=[{'IAFO'}];
selectedAlgorithm=[{@IAFO_Final1}];
data.sizeMap0=mapSize;
option.maxIteration=mapSize*1000/option.numAgent;    %最大迭代次数
option.maxEfs=mapSize*1000;
option.dim=dim;
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
lb=-ones(1,dim)*0;
ub=ones(1,dim)*1;
option.lb=lb;
option.ub=ub;
%%
%% 初始化种群个体
%% 使用算法求解
for ii=1:length(selectedAlgorithm)
    option.fobj=@aimFcn_PPP;
    x=ones(option.numAgent,option.dim);
    y=ones(option.numAgent,1);
    for i=1:option.numAgent
        x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
        y(i)=option.fobj(x(i,:),option,data);
    end
    rng(noRNG)
    tic
    [bestY(ii,:),bestX(ii,:),recording{ii}]=selectedAlgorithm{ii}(x,y,option,data);
    recordingT(ii,j)=toc;
end
%%
figure
hold on
plot(recording{1}.bestFit_EFs(1:option.maxEfs),'LineWidth',2)
legend(str_legend)
set(gca,'LooseInset',get(gca,'TightInset'))
%%
rng(1)
option.color=rand(50,3)*0.5+0.5;
for ii=1:length(selectedAlgorithm)
    option.fobj=@aimFcn_PPP;
    str=str_legend{ii};
    [fit(ii),result(ii)]=option.fobj(bestX(ii,:),option,data);
    drawPc_PPP(result(ii),option,data,str)
end